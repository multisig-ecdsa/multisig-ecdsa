#include <FL/Fl.H>
#include <FL/Fl_Window.H>
#include <FL/fl_draw.H>
int main() {
  &fl_color_cube;
  return 0;
}
