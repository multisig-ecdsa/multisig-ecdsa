#include <stdio.h>
#include <readline/readline.h>
int main(){ printf("%s\n", rl_library_version); return 0; }
